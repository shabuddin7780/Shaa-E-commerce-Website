import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { CheckCheck } from 'lucide-react';

type CheckoutStep = 'shipping' | 'payment' | 'confirmation';

interface ShippingFormData {
  firstName: string;
  lastName: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  email: string;
  phone: string;
}

interface PaymentFormData {
  cardName: string;
  cardNumber: string;
  expMonth: string;
  expYear: string;
  cvv: string;
}

const initialShippingData: ShippingFormData = {
  firstName: '',
  lastName: '',
  address: '',
  city: '',
  state: '',
  zipCode: '',
  email: '',
  phone: ''
};

const initialPaymentData: PaymentFormData = {
  cardName: '',
  cardNumber: '',
  expMonth: '',
  expYear: '',
  cvv: ''
};

const CheckoutPage: React.FC = () => {
  const { cartItems, subtotal, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [currentStep, setCurrentStep] = useState<CheckoutStep>('shipping');
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');
  
  const [shippingData, setShippingData] = useState<ShippingFormData>(initialShippingData);
  const [paymentData, setPaymentData] = useState<PaymentFormData>(initialPaymentData);
  
  useEffect(() => {
    document.title = 'Checkout | PrintShop';
    
    // Redirect to cart if cart is empty
    if (cartItems.length === 0 && !orderComplete) {
      navigate('/cart');
    }
    
    // Pre-fill email if user is logged in
    if (user) {
      setShippingData(prev => ({
        ...prev,
        email: user.email,
        firstName: user.name.split(' ')[0],
        lastName: user.name.split(' ').slice(1).join(' ')
      }));
    }
  }, [cartItems.length, navigate, user, orderComplete]);
  
  // Calculate order totals
  const calculateShipping = () => {
    if (subtotal >= 75) return 0; // Free shipping over $75
    return 10.99; // Standard shipping
  };

  const shipping = calculateShipping();
  const tax = subtotal * 0.08; // 8% tax
  const total = subtotal + shipping + tax;
  
  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Validate shipping form
    setCurrentStep('payment');
    window.scrollTo(0, 0);
  };
  
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Process payment (mock)
    processOrder();
  };
  
  const processOrder = () => {
    // Simulate order processing
    setTimeout(() => {
      // Generate a random order number
      const orderNum = `ORD-${Math.floor(Math.random() * 100000)}`;
      setOrderNumber(orderNum);
      setOrderComplete(true);
      clearCart();
      window.scrollTo(0, 0);
    }, 1500);
  };
  
  const handleShippingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setShippingData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handlePaymentChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setPaymentData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Order confirmation screen
  if (orderComplete) {
    return (
      <div className="bg-gray-50 py-12">
        <div className="max-w-screen-xl mx-auto px-4">
          <div className="bg-white rounded-lg shadow-sm p-8 text-center max-w-md mx-auto">
            <div className="mb-6 flex justify-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCheck size={32} className="text-green-600" />
              </div>
            </div>
            <h1 className="text-2xl font-bold mb-4">Order Placed Successfully!</h1>
            <p className="text-gray-600 mb-4">
              Thank you for your order. We'll send you a confirmation email shortly.
            </p>
            <div className="bg-gray-50 p-4 rounded-md mb-6">
              <p className="font-medium">Order Number:</p>
              <p className="text-xl font-bold text-blue-700">{orderNumber}</p>
            </div>
            <button
              onClick={() => navigate('/')}
              className="bg-blue-700 hover:bg-blue-800 text-white font-medium py-3 px-6 rounded-md transition duration-300"
            >
              Return to Home
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-50 py-8">
      <div className="max-w-screen-xl mx-auto px-4">
        <h1 className="text-2xl font-bold mb-6">Checkout</h1>
        
        {/* Checkout steps */}
        <div className="mb-8">
          <div className="flex items-center">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              currentStep === 'shipping' ? 'bg-blue-700 text-white' : 'bg-blue-700 text-white'
            }`}>
              1
            </div>
            <div className="h-1 w-24 mx-2 bg-gray-300">
              <div className={`h-full ${
                currentStep !== 'shipping' ? 'bg-blue-700' : 'bg-gray-300'
              }`}></div>
            </div>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              currentStep === 'payment' ? 'bg-blue-700 text-white' : 
              currentStep === 'confirmation' ? 'bg-blue-700 text-white' : 'bg-gray-300 text-gray-700'
            }`}>
              2
            </div>
            <div className="h-1 w-24 mx-2 bg-gray-300">
              <div className={`h-full ${
                currentStep === 'confirmation' ? 'bg-blue-700' : 'bg-gray-300'
              }`}></div>
            </div>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              currentStep === 'confirmation' ? 'bg-blue-700 text-white' : 'bg-gray-300 text-gray-700'
            }`}>
              3
            </div>
          </div>
          <div className="flex justify-between mt-2 text-sm">
            <span className="font-medium">Shipping</span>
            <span className="font-medium">Payment</span>
            <span className="font-medium">Confirmation</span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main form area */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              {/* Shipping info step */}
              {currentStep === 'shipping' && (
                <div>
                  <div className="p-6 border-b border-gray-200">
                    <h2 className="text-lg font-semibold">Shipping Information</h2>
                  </div>
                  
                  <form onSubmit={handleShippingSubmit} className="p-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                      <div>
                        <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                          First Name *
                        </label>
                        <input
                          type="text"
                          id="firstName"
                          name="firstName"
                          required
                          value={shippingData.firstName}
                          onChange={handleShippingChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                          Last Name *
                        </label>
                        <input
                          type="text"
                          id="lastName"
                          name="lastName"
                          required
                          value={shippingData.lastName}
                          onChange={handleShippingChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                        Street Address *
                      </label>
                      <input
                        type="text"
                        id="address"
                        name="address"
                        required
                        value={shippingData.address}
                        onChange={handleShippingChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
                      <div>
                        <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
                          City *
                        </label>
                        <input
                          type="text"
                          id="city"
                          name="city"
                          required
                          value={shippingData.city}
                          onChange={handleShippingChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-1">
                          State *
                        </label>
                        <select
                          id="state"
                          name="state"
                          required
                          value={shippingData.state}
                          onChange={handleShippingChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          <option value="">Select State</option>
                          <option value="AL">Alabama</option>
                          <option value="AK">Alaska</option>
                          <option value="AZ">Arizona</option>
                          <option value="CA">California</option>
                          <option value="CO">Colorado</option>
                          <option value="FL">Florida</option>
                          <option value="GA">Georgia</option>
                          <option value="NY">New York</option>
                          <option value="TX">Texas</option>
                          {/* Add other states */}
                        </select>
                      </div>
                      <div>
                        <label htmlFor="zipCode" className="block text-sm font-medium text-gray-700 mb-1">
                          ZIP Code *
                        </label>
                        <input
                          type="text"
                          id="zipCode"
                          name="zipCode"
                          required
                          value={shippingData.zipCode}
                          onChange={handleShippingChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          required
                          value={shippingData.email}
                          onChange={handleShippingChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                          Phone Number *
                        </label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          required
                          value={shippingData.phone}
                          onChange={handleShippingChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <button
                        type="submit"
                        className="w-full bg-blue-700 hover:bg-blue-800 text-white font-medium py-3 px-4 rounded-md transition duration-300"
                      >
                        Continue to Payment
                      </button>
                    </div>
                  </form>
                </div>
              )}
              
              {/* Payment info step */}
              {currentStep === 'payment' && (
                <div>
                  <div className="p-6 border-b border-gray-200">
                    <h2 className="text-lg font-semibold">Payment Information</h2>
                  </div>
                  
                  <form onSubmit={handlePaymentSubmit} className="p-6">
                    <div className="mb-6">
                      <div className="flex items-center mb-4">
                        <h3 className="text-base font-medium">Shipping Address</h3>
                        <button
                          type="button"
                          onClick={() => setCurrentStep('shipping')}
                          className="ml-auto text-sm text-blue-700 hover:text-blue-900"
                        >
                          Edit
                        </button>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-md">
                        <p className="text-gray-700">
                          {shippingData.firstName} {shippingData.lastName}<br />
                          {shippingData.address}<br />
                          {shippingData.city}, {shippingData.state} {shippingData.zipCode}<br />
                          {shippingData.email}<br />
                          {shippingData.phone}
                        </p>
                      </div>
                    </div>
                    
                    <div className="border-t border-gray-200 pt-6">
                      <h3 className="text-base font-medium mb-4">Card Details</h3>
                      
                      <div className="mb-4">
                        <label htmlFor="cardName" className="block text-sm font-medium text-gray-700 mb-1">
                          Name on Card *
                        </label>
                        <input
                          type="text"
                          id="cardName"
                          name="cardName"
                          required
                          value={paymentData.cardName}
                          onChange={handlePaymentChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      
                      <div className="mb-4">
                        <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700 mb-1">
                          Card Number *
                        </label>
                        <input
                          type="text"
                          id="cardNumber"
                          name="cardNumber"
                          required
                          placeholder="•••• •••• •••• ••••"
                          value={paymentData.cardNumber}
                          onChange={handlePaymentChange}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 mb-6">
                        <div>
                          <label htmlFor="expMonth" className="block text-sm font-medium text-gray-700 mb-1">
                            Exp. Month *
                          </label>
                          <select
                            id="expMonth"
                            name="expMonth"
                            required
                            value={paymentData.expMonth}
                            onChange={handlePaymentChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          >
                            <option value="">Month</option>
                            {[...Array(12)].map((_, i) => (
                              <option key={i} value={i + 1}>{i + 1}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label htmlFor="expYear" className="block text-sm font-medium text-gray-700 mb-1">
                            Exp. Year *
                          </label>
                          <select
                            id="expYear"
                            name="expYear"
                            required
                            value={paymentData.expYear}
                            onChange={handlePaymentChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          >
                            <option value="">Year</option>
                            {[...Array(10)].map((_, i) => {
                              const year = new Date().getFullYear() + i;
                              return (
                                <option key={year} value={year}>{year}</option>
                              );
                            })}
                          </select>
                        </div>
                        <div>
                          <label htmlFor="cvv" className="block text-sm font-medium text-gray-700 mb-1">
                            CVV *
                          </label>
                          <input
                            type="text"
                            id="cvv"
                            name="cvv"
                            required
                            placeholder="•••"
                            value={paymentData.cvv}
                            onChange={handlePaymentChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6 flex flex-col sm:flex-row sm:justify-between sm:space-x-4">
                      <button
                        type="button"
                        onClick={() => setCurrentStep('shipping')}
                        className="w-full sm:w-auto mb-3 sm:mb-0 bg-white border border-gray-300 hover:border-blue-700 text-gray-700 hover:text-blue-700 font-medium py-3 px-4 rounded-md transition duration-300"
                      >
                        Back to Shipping
                      </button>
                      <button
                        type="submit"
                        className="w-full sm:w-auto bg-blue-700 hover:bg-blue-800 text-white font-medium py-3 px-4 rounded-md transition duration-300"
                      >
                        Complete Order
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
          
          {/* Order summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden sticky top-4">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-lg font-semibold">Order Summary</h2>
              </div>
              
              <div className="p-6">
                <div className="max-h-64 overflow-y-auto mb-4">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex mb-4 pb-4 border-b border-gray-200 last:border-0 last:pb-0 last:mb-0">
                      <div className="w-16 h-16">
                        <img 
                          src={item.image} 
                          alt={item.name}
                          className="w-full h-full object-cover rounded-md"
                        />
                      </div>
                      <div className="ml-4">
                        <div className="font-medium text-gray-900 line-clamp-1">{item.name}</div>
                        <div className="text-sm text-gray-500">Qty: {item.quantity}</div>
                        <div className="font-medium mt-1">${(item.price * item.quantity).toFixed(2)}</div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="text-gray-900 font-medium">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Shipping</span>
                    {shipping === 0 ? (
                      <span className="text-green-600 font-medium">Free</span>
                    ) : (
                      <span className="text-gray-900 font-medium">${shipping.toFixed(2)}</span>
                    )}
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Estimated Tax</span>
                    <span className="text-gray-900 font-medium">${tax.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-gray-200 pt-4 mt-4">
                    <div className="flex justify-between font-bold">
                      <span>Total</span>
                      <span className="text-blue-700">${total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;