import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Star, Minus, Plus, Check, ShoppingCart, Heart, Share2 } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { getProductById, Product } from '../data/products';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [mainImage, setMainImage] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({});
  const [activeTab, setActiveTab] = useState<'description' | 'features' | 'reviews'>('description');

  useEffect(() => {
    if (id) {
      const foundProduct = getProductById(id);
      if (foundProduct) {
        setProduct(foundProduct);
        setMainImage(foundProduct.images[0]);
        
        // Initialize selected options with defaults
        if (foundProduct.customizationOptions) {
          const initialOptions: Record<string, string> = {};
          foundProduct.customizationOptions.forEach(option => {
            initialOptions[option.name] = option.options[0].value;
          });
          setSelectedOptions(initialOptions);
        }
      }
    }
    setLoading(false);
  }, [id]);

  useEffect(() => {
    if (product) {
      document.title = `${product.name} | PrintShop`;
    }
  }, [product]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-700"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-screen-xl mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold mb-4">Product Not Found</h1>
        <p className="mb-8">Sorry, we couldn't find the product you're looking for.</p>
        <button
          onClick={() => navigate('/products')}
          className="bg-blue-700 hover:bg-blue-800 text-white py-2 px-6 rounded-md transition duration-300"
        >
          Browse All Products
        </button>
      </div>
    );
  }

  const handleQuantityChange = (delta: number) => {
    setQuantity(prev => Math.max(1, prev + delta));
  };

  const handleOptionChange = (optionName: string, value: string) => {
    setSelectedOptions(prev => ({
      ...prev,
      [optionName]: value
    }));
  };

  const calculateTotalPrice = () => {
    let basePrice = product.salePrice || product.price;
    
    // Add option prices if applicable
    if (product.customizationOptions) {
      product.customizationOptions.forEach(optionGroup => {
        const selectedValue = selectedOptions[optionGroup.name];
        const selectedOption = optionGroup.options.find(opt => opt.value === selectedValue);
        if (selectedOption && selectedOption.price !== undefined) {
          // If the option has an absolute price (like quantity options)
          if (optionGroup.name.toLowerCase() === 'quantity') {
            basePrice = selectedOption.price;
          } else {
            // If the option has a price modifier
            basePrice += selectedOption.price;
          }
        }
      });
    }
    
    return (basePrice * quantity).toFixed(2);
  };

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: parseFloat(calculateTotalPrice()),
      image: product.images[0],
      quantity: quantity,
      options: selectedOptions
    });
  };

  return (
    <div className="bg-gray-50 py-8">
      <div className="max-w-screen-xl mx-auto px-4">
        {/* Breadcrumbs */}
        <nav className="mb-6">
          <ol className="flex text-sm">
            <li>
              <a href="/" className="text-gray-500 hover:text-blue-700">Home</a>
            </li>
            <li className="mx-2 text-gray-500">/</li>
            <li>
              <a href="/products" className="text-gray-500 hover:text-blue-700">Products</a>
            </li>
            <li className="mx-2 text-gray-500">/</li>
            <li>
              <a href={`/products?category=${product.category.toLowerCase()}`} className="text-gray-500 hover:text-blue-700">{product.category}</a>
            </li>
            <li className="mx-2 text-gray-500">/</li>
            <li className="text-gray-700 font-medium truncate">{product.name}</li>
          </ol>
        </nav>
        
        {/* Product display */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 p-6">
            {/* Product images */}
            <div className="lg:col-span-2">
              <div className="mb-4 rounded-lg overflow-hidden border border-gray-200">
                <img 
                  src={mainImage} 
                  alt={product.name}
                  className="w-full h-auto object-contain aspect-square"
                />
              </div>
              <div className="grid grid-cols-4 gap-2">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setMainImage(image)}
                    className={`border rounded-md overflow-hidden ${
                      mainImage === image ? 'border-blue-700 ring-2 ring-blue-200' : 'border-gray-200'
                    }`}
                  >
                    <img 
                      src={image} 
                      alt={`${product.name} view ${index + 1}`}
                      className="w-full h-auto aspect-square object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>
            
            {/* Product info */}
            <div className="lg:col-span-3">
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
                {product.name}
              </h1>
              
              <div className="flex items-center mb-4">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={18}
                      className={`${
                        i < Math.floor(product.rating) 
                          ? 'text-yellow-400 fill-yellow-400' 
                          : i < product.rating 
                            ? 'text-yellow-400 fill-yellow-400 opacity-50' 
                            : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="ml-2 text-sm text-gray-600">{product.rating.toFixed(1)} ({product.reviews} reviews)</span>
              </div>
              
              <div className="mb-6">
                {product.salePrice ? (
                  <div>
                    <span className="text-2xl font-bold text-blue-700 mr-2">${calculateTotalPrice()}</span>
                    <span className="text-lg text-gray-500 line-through">${(product.price * quantity).toFixed(2)}</span>
                    <span className="ml-2 bg-red-100 text-red-700 text-sm font-medium px-2 py-0.5 rounded">
                      SAVE {(((product.price - product.salePrice) / product.price) * 100).toFixed(0)}%
                    </span>
                  </div>
                ) : (
                  <span className="text-2xl font-bold text-blue-700">${calculateTotalPrice()}</span>
                )}
              </div>
              
              <div className="mb-6">
                <p className="text-gray-700">{product.description}</p>
              </div>
              
              {/* Customization options */}
              {product.customizationOptions && (
                <div className="space-y-6 mb-6">
                  {product.customizationOptions.map((optionGroup) => (
                    <div key={optionGroup.name}>
                      <h3 className="text-sm font-medium text-gray-700 mb-3">{optionGroup.name}</h3>
                      
                      {optionGroup.type === 'select' && (
                        <select
                          value={selectedOptions[optionGroup.name] || ''}
                          onChange={(e) => handleOptionChange(optionGroup.name, e.target.value)}
                          className="w-full border border-gray-300 rounded-md py-2 pl-3 pr-10 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        >
                          {optionGroup.options.map((option) => (
                            <option key={option.id} value={option.value}>
                              {option.name} {option.price !== undefined && optionGroup.name !== 'Quantity' ? `(${option.price > 0 ? '+' : ''}$${option.price.toFixed(2)})` : ''}
                            </option>
                          ))}
                        </select>
                      )}
                      
                      {optionGroup.type === 'radio' && (
                        <div className="grid grid-cols-2 gap-3">
                          {optionGroup.options.map((option) => (
                            <div key={option.id} className="relative">
                              <input
                                type="radio"
                                id={option.id}
                                name={optionGroup.name}
                                value={option.value}
                                checked={selectedOptions[optionGroup.name] === option.value}
                                onChange={() => handleOptionChange(optionGroup.name, option.value)}
                                className="sr-only"
                              />
                              <label
                                htmlFor={option.id}
                                className={`
                                  flex items-center justify-between p-3 border rounded-md cursor-pointer
                                  ${selectedOptions[optionGroup.name] === option.value 
                                    ? 'bg-blue-50 border-blue-700 text-blue-700' 
                                    : 'border-gray-300 text-gray-700'}
                                `}
                              >
                                <span>{option.name}</span>
                                {selectedOptions[optionGroup.name] === option.value && (
                                  <Check size={16} className="text-blue-700" />
                                )}
                              </label>
                              {option.price && (
                                <span className="text-xs text-gray-500 mt-1 block">
                                  {option.price > 0 ? `+$${option.price.toFixed(2)}` : `-$${Math.abs(option.price).toFixed(2)}`}
                                </span>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {optionGroup.type === 'color' && (
                        <div className="flex flex-wrap gap-3">
                          {optionGroup.options.map((option) => (
                            <div key={option.id} className="relative">
                              <input
                                type="radio"
                                id={option.id}
                                name={optionGroup.name}
                                value={option.value}
                                checked={selectedOptions[optionGroup.name] === option.value}
                                onChange={() => handleOptionChange(optionGroup.name, option.value)}
                                className="sr-only"
                              />
                              <label
                                htmlFor={option.id}
                                className={`
                                  flex flex-col items-center cursor-pointer
                                `}
                              >
                                <span 
                                  className={`
                                    block w-8 h-8 rounded-full border-2
                                    ${selectedOptions[optionGroup.name] === option.value 
                                      ? 'border-blue-700' 
                                      : 'border-gray-300'}
                                  `}
                                  style={{ backgroundColor: option.value }}
                                ></span>
                                <span className="text-xs mt-1 text-gray-700">{option.name}</span>
                              </label>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
              
              {/* Quantity and Add to Cart */}
              <div className="sm:flex items-center mb-6">
                <div className="flex items-center border border-gray-300 rounded-md mb-4 sm:mb-0 sm:mr-4">
                  <button
                    onClick={() => handleQuantityChange(-1)}
                    className="px-3 py-2 text-gray-600 hover:text-blue-700 focus:outline-none"
                    disabled={quantity <= 1}
                  >
                    <Minus size={16} />
                  </button>
                  <span className="px-4 py-2 text-gray-800 font-medium">{quantity}</span>
                  <button
                    onClick={() => handleQuantityChange(1)}
                    className="px-3 py-2 text-gray-600 hover:text-blue-700 focus:outline-none"
                  >
                    <Plus size={16} />
                  </button>
                </div>
                
                <button
                  onClick={handleAddToCart}
                  className="w-full sm:w-auto bg-blue-700 hover:bg-blue-800 text-white py-2 px-6 rounded-md transition duration-300 flex items-center justify-center"
                >
                  <ShoppingCart size={18} className="mr-2" />
                  Add to Cart
                </button>
                
                <button
                  className="ml-4 p-2 text-gray-600 hover:text-blue-700 border border-gray-300 rounded-md hidden sm:flex"
                  aria-label="Add to wishlist"
                >
                  <Heart size={18} />
                </button>
                
                <button
                  className="ml-2 p-2 text-gray-600 hover:text-blue-700 border border-gray-300 rounded-md hidden sm:flex"
                  aria-label="Share product"
                >
                  <Share2 size={18} />
                </button>
              </div>
              
              {/* Stock info */}
              <div className="flex items-center text-sm">
                {product.inStock ? (
                  <div className="flex items-center text-green-600">
                    <Check size={16} className="mr-1" />
                    <span>In Stock</span>
                  </div>
                ) : (
                  <div className="text-red-600">Out of Stock</div>
                )}
              </div>
            </div>
          </div>
          
          {/* Tabs */}
          <div className="border-t border-gray-200 mt-8">
            <div className="flex border-b border-gray-200">
              <button
                onClick={() => setActiveTab('description')}
                className={`py-4 px-6 text-sm font-medium ${
                  activeTab === 'description' 
                    ? 'border-b-2 border-blue-700 text-blue-700' 
                    : 'text-gray-600 hover:text-blue-700'
                }`}
              >
                Description
              </button>
              <button
                onClick={() => setActiveTab('features')}
                className={`py-4 px-6 text-sm font-medium ${
                  activeTab === 'features' 
                    ? 'border-b-2 border-blue-700 text-blue-700' 
                    : 'text-gray-600 hover:text-blue-700'
                }`}
              >
                Features
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`py-4 px-6 text-sm font-medium ${
                  activeTab === 'reviews' 
                    ? 'border-b-2 border-blue-700 text-blue-700' 
                    : 'text-gray-600 hover:text-blue-700'
                }`}
              >
                Reviews ({product.reviews})
              </button>
            </div>
            
            <div className="p-6">
              {activeTab === 'description' && (
                <div className="prose max-w-none">
                  <p>{product.description}</p>
                </div>
              )}
              
              {activeTab === 'features' && (
                <div>
                  <h3 className="text-lg font-semibold mb-4">Product Features</h3>
                  <ul className="space-y-2">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check size={18} className="text-green-600 mr-2 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              
              {activeTab === 'reviews' && (
                <div>
                  <div className="flex items-center mb-4">
                    <span className="text-3xl font-bold mr-4">{product.rating.toFixed(1)}</span>
                    <div>
                      <div className="flex mb-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            size={20}
                            className={`${
                              i < Math.floor(product.rating) 
                                ? 'text-yellow-400 fill-yellow-400' 
                                : i < product.rating 
                                  ? 'text-yellow-400 fill-yellow-400 opacity-50' 
                                  : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">Based on {product.reviews} reviews</span>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mt-4">
                    Customer reviews will be displayed here. This is a demo and doesn't contain actual reviews.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;