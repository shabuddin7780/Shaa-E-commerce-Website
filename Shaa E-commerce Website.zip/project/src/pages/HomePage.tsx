import React, { useEffect } from 'react';
import HeroSection from '../components/home/HeroSection';
import FeaturedCategories from '../components/home/FeaturedCategories';
import FeaturedProducts from '../components/home/FeaturedProducts';
import TestimonialSection from '../components/home/TestimonialSection';
import CallToAction from '../components/home/CallToAction';

const HomePage: React.FC = () => {
  useEffect(() => {
    document.title = 'PrintShop - Custom Printing Solutions';
  }, []);

  return (
    <div>
      <HeroSection />
      <FeaturedCategories />
      <FeaturedProducts />
      <TestimonialSection />
      <CallToAction />
    </div>
  );
};

export default HomePage;