import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

const CartPage: React.FC = () => {
  const { cartItems, removeFromCart, updateQuantity, subtotal } = useCart();

  useEffect(() => {
    document.title = 'Your Cart | PrintShop';
  }, []);

  // Calculate shipping cost based on cart total
  const calculateShipping = () => {
    if (subtotal >= 75) return 0; // Free shipping over $75
    if (subtotal === 0) return 0; // No shipping if cart is empty
    return 10.99; // Standard shipping
  };

  const shipping = calculateShipping();
  const tax = subtotal * 0.08; // 8% tax
  const total = subtotal + shipping + tax;

  if (cartItems.length === 0) {
    return (
      <div className="bg-gray-50 py-12">
        <div className="max-w-screen-xl mx-auto px-4">
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <div className="flex justify-center mb-6">
              <ShoppingBag size={64} className="text-gray-400" />
            </div>
            <h1 className="text-2xl font-bold mb-4">Your Cart is Empty</h1>
            <p className="text-gray-600 mb-8">
              Looks like you haven't added any products to your cart yet.
            </p>
            <Link
              to="/products"
              className="bg-blue-700 hover:bg-blue-800 text-white font-medium py-3 px-6 rounded-md transition duration-300"
            >
              Start Shopping
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 py-8">
      <div className="max-w-screen-xl mx-auto px-4">
        <h1 className="text-2xl font-bold mb-6">Your Shopping Cart</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart items */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-lg font-semibold">
                  Cart Items ({cartItems.length})
                </h2>
              </div>
              
              <div className="divide-y divide-gray-200">
                {cartItems.map((item) => (
                  <div key={item.id} className="p-6 flex flex-col sm:flex-row">
                    {/* Product image */}
                    <div className="sm:w-24 sm:h-24 mb-4 sm:mb-0">
                      <Link to={`/products/${item.id}`}>
                        <img 
                          src={item.image} 
                          alt={item.name}
                          className="w-full h-full object-cover rounded-md"
                        />
                      </Link>
                    </div>
                    
                    {/* Product details */}
                    <div className="flex-1 sm:ml-6">
                      <div className="flex flex-col sm:flex-row sm:justify-between">
                        <div>
                          <Link 
                            to={`/products/${item.id}`}
                            className="text-lg font-medium text-gray-900 hover:text-blue-700"
                          >
                            {item.name}
                          </Link>
                          
                          {/* Product options */}
                          {item.options && Object.keys(item.options).length > 0 && (
                            <div className="mt-1 text-sm text-gray-500">
                              {Object.entries(item.options).map(([key, value]) => (
                                <div key={key}>
                                  {key}: <span className="font-medium">{value}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                        
                        <div className="text-right mt-2 sm:mt-0">
                          <div className="text-lg font-medium text-gray-900">
                            ${(item.price * item.quantity).toFixed(2)}
                          </div>
                          <div className="text-sm text-gray-600">
                            ${item.price.toFixed(2)} each
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between mt-4">
                        {/* Quantity controls */}
                        <div className="flex items-center border border-gray-300 rounded-md">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="px-3 py-1 text-gray-600 hover:text-blue-700 focus:outline-none"
                            disabled={item.quantity <= 1}
                          >
                            <Minus size={16} />
                          </button>
                          <span className="px-4 py-1 text-gray-800 font-medium">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="px-3 py-1 text-gray-600 hover:text-blue-700 focus:outline-none"
                          >
                            <Plus size={16} />
                          </button>
                        </div>
                        
                        {/* Remove button */}
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-gray-500 hover:text-red-600 flex items-center"
                        >
                          <Trash2 size={16} className="mr-1" />
                          <span className="text-sm">Remove</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Order summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden sticky top-4">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-lg font-semibold">Order Summary</h2>
              </div>
              
              <div className="p-6">
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="text-gray-900 font-medium">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Shipping</span>
                    {shipping === 0 ? (
                      <span className="text-green-600 font-medium">Free</span>
                    ) : (
                      <span className="text-gray-900 font-medium">${shipping.toFixed(2)}</span>
                    )}
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Estimated Tax</span>
                    <span className="text-gray-900 font-medium">${tax.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-gray-200 pt-4 mt-4">
                    <div className="flex justify-between font-bold">
                      <span>Total</span>
                      <span className="text-blue-700">${total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <Link
                    to="/checkout"
                    className="block w-full bg-blue-700 hover:bg-blue-800 text-white font-medium py-3 px-4 rounded-md text-center transition duration-300"
                  >
                    Proceed to Checkout
                  </Link>
                </div>
                
                <div className="mt-4">
                  <Link
                    to="/products"
                    className="block w-full bg-white border border-gray-300 hover:border-blue-700 text-gray-700 hover:text-blue-700 font-medium py-3 px-4 rounded-md text-center transition duration-300"
                  >
                    Continue Shopping
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;