// Mock product data
export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  salePrice?: number;
  description: string;
  features: string[];
  images: string[];
  customizationOptions?: {
    name: string;
    type: 'select' | 'radio' | 'color';
    options: {
      id: string;
      name: string;
      value: string;
      price?: number;
    }[];
  }[];
  inStock: boolean;
  rating: number;
  reviews: number;
  isNew?: boolean;
  isFeatured?: boolean;
  tags?: string[];
}

const products: Product[] = [
  {
    id: '1',
    name: 'Premium Business Cards',
    category: 'Business Cards',
    price: 19.99,
    description: 'Make a lasting impression with our premium business cards. Printed on high-quality 350gsm silk card with options for matt or gloss finish.',
    features: [
      '350gsm premium silk card',
      'Full color double sided printing',
      'Matt or gloss lamination options',
      'Standard size: 85mm x 55mm',
      'Rounded corners available'
    ],
    images: [
      'https://images.pexels.com/photos/6177607/pexels-photo-6177607.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/6177599/pexels-photo-6177599.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    customizationOptions: [
      {
        name: 'Quantity',
        type: 'select',
        options: [
          { id: 'qty-100', name: '100 Cards', value: '100', price: 19.99 },
          { id: 'qty-250', name: '250 Cards', value: '250', price: 39.99 },
          { id: 'qty-500', name: '500 Cards', value: '500', price: 69.99 },
          { id: 'qty-1000', name: '1000 Cards', value: '1000', price: 99.99 }
        ]
      },
      {
        name: 'Finish',
        type: 'select',
        options: [
          { id: 'finish-matt', name: 'Matt Lamination', value: 'matt' },
          { id: 'finish-gloss', name: 'Gloss Lamination', value: 'gloss' },
          { id: 'finish-none', name: 'No Lamination', value: 'none' }
        ]
      },
      {
        name: 'Corners',
        type: 'radio',
        options: [
          { id: 'corners-square', name: 'Square Corners', value: 'square' },
          { id: 'corners-rounded', name: 'Rounded Corners', value: 'rounded', price: 5.00 }
        ]
      }
    ],
    inStock: true,
    rating: 4.8,
    reviews: 124,
    isFeatured: true
  },
  {
    id: '2',
    name: 'Custom T-Shirts',
    category: 'T-Shirts',
    price: 24.99,
    description: 'High-quality custom printed t-shirts perfect for events, promotions, or personal use. Made from 100% cotton for comfort and durability.',
    features: [
      '100% premium cotton',
      'Available in multiple colors',
      'Sizes from S to 3XL',
      'Screen printing or DTG options',
      'Fast turnaround time'
    ],
    images: [
      'https://images.pexels.com/photos/1656684/pexels-photo-1656684.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/6767790/pexels-photo-6767790.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    customizationOptions: [
      {
        name: 'Size',
        type: 'select',
        options: [
          { id: 'size-s', name: 'Small', value: 'S' },
          { id: 'size-m', name: 'Medium', value: 'M' },
          { id: 'size-l', name: 'Large', value: 'L' },
          { id: 'size-xl', name: 'X-Large', value: 'XL' },
          { id: 'size-2xl', name: '2X-Large', value: '2XL', price: 2.00 },
          { id: 'size-3xl', name: '3X-Large', value: '3XL', price: 4.00 }
        ]
      },
      {
        name: 'Color',
        type: 'color',
        options: [
          { id: 'color-white', name: 'White', value: '#FFFFFF' },
          { id: 'color-black', name: 'Black', value: '#000000' },
          { id: 'color-navy', name: 'Navy Blue', value: '#000080' },
          { id: 'color-red', name: 'Red', value: '#FF0000' },
          { id: 'color-green', name: 'Green', value: '#008000' }
        ]
      },
      {
        name: 'Quantity',
        type: 'select',
        options: [
          { id: 'qty-10', name: '10 Shirts', value: '10', price: 24.99 },
          { id: 'qty-25', name: '25 Shirts', value: '25', price: 22.99 },
          { id: 'qty-50', name: '50 Shirts', value: '50', price: 19.99 },
          { id: 'qty-100', name: '100 Shirts', value: '100', price: 17.99 }
        ]
      }
    ],
    inStock: true,
    rating: 4.5,
    reviews: 89,
    isFeatured: true
  },
  {
    id: '3',
    name: 'Custom Brochures',
    category: 'Brochures',
    price: 89.99,
    description: 'Professional brochures for your business or event. Printed on high-quality paper with vibrant colors and sharp text.',
    features: [
      'Available in various sizes',
      'Bi-fold or tri-fold options',
      'Full color printing on both sides',
      '170gsm silk paper stock',
      'Quick turnaround time'
    ],
    images: [
      'https://images.pexels.com/photos/7295251/pexels-photo-7295251.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/5699366/pexels-photo-5699366.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    customizationOptions: [
      {
        name: 'Size',
        type: 'select',
        options: [
          { id: 'size-a4', name: 'A4 (210 x 297mm)', value: 'A4' },
          { id: 'size-a5', name: 'A5 (148 x 210mm)', value: 'A5', price: -10.00 },
          { id: 'size-dl', name: 'DL (99 x 210mm)', value: 'DL', price: -15.00 }
        ]
      },
      {
        name: 'Fold',
        type: 'radio',
        options: [
          { id: 'fold-bi', name: 'Bi-fold', value: 'bi' },
          { id: 'fold-tri', name: 'Tri-fold', value: 'tri', price: 5.00 }
        ]
      },
      {
        name: 'Quantity',
        type: 'select',
        options: [
          { id: 'qty-100', name: '100 Brochures', value: '100', price: 89.99 },
          { id: 'qty-250', name: '250 Brochures', value: '250', price: 119.99 },
          { id: 'qty-500', name: '500 Brochures', value: '500', price: 199.99 },
          { id: 'qty-1000', name: '1000 Brochures', value: '1000', price: 299.99 }
        ]
      }
    ],
    inStock: true,
    rating: 4.7,
    reviews: 42,
    isFeatured: false
  },
  {
    id: '4',
    name: 'Vinyl Banners',
    category: 'Banners',
    price: 49.99,
    salePrice: 39.99,
    description: 'Eye-catching vinyl banners for indoor or outdoor use. Perfect for trade shows, events, or storefronts. Weather-resistant and durable.',
    features: [
      '440gsm heavy-duty vinyl',
      'Water and UV resistant',
      'Brass eyelets included',
      'Custom sizes available',
      'Vibrant full color printing'
    ],
    images: [
      'https://images.pexels.com/photos/4481262/pexels-photo-4481262.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    customizationOptions: [
      {
        name: 'Size',
        type: 'select',
        options: [
          { id: 'size-6x2', name: '6ft x 2ft', value: '6x2', price: 49.99 },
          { id: 'size-8x3', name: '8ft x 3ft', value: '8x3', price: 69.99 },
          { id: 'size-10x3', name: '10ft x 3ft', value: '10x3', price: 89.99 },
          { id: 'size-custom', name: 'Custom Size', value: 'custom', price: 99.99 }
        ]
      },
      {
        name: 'Finish',
        type: 'select',
        options: [
          { id: 'finish-standard', name: 'Standard Finish', value: 'standard' },
          { id: 'finish-hemmed', name: 'Hemmed Edges', value: 'hemmed', price: 10.00 },
          { id: 'finish-pole', name: 'Pole Pockets', value: 'pole', price: 15.00 }
        ]
      }
    ],
    inStock: true,
    rating: 4.6,
    reviews: 68,
    isNew: true,
    isFeatured: true
  },
  {
    id: '5',
    name: 'Promotional Flyers',
    category: 'Flyers',
    price: 29.99,
    description: 'Get the word out with our high-quality promotional flyers. Great for events, sales, or general advertising.',
    features: [
      '170gsm gloss paper',
      'Full color double sided printing',
      'A5 and A6 sizes available',
      'Fast turnaround time',
      'Bulk discounts available'
    ],
    images: [
      'https://images.pexels.com/photos/3774043/pexels-photo-3774043.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/4245923/pexels-photo-4245923.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    customizationOptions: [
      {
        name: 'Size',
        type: 'radio',
        options: [
          { id: 'size-a5', name: 'A5 (148 x 210mm)', value: 'A5', price: 29.99 },
          { id: 'size-a6', name: 'A6 (105 x 148mm)', value: 'A6', price: 19.99 }
        ]
      },
      {
        name: 'Quantity',
        type: 'select',
        options: [
          { id: 'qty-100', name: '100 Flyers', value: '100' },
          { id: 'qty-250', name: '250 Flyers', value: '250', price: 59.99 },
          { id: 'qty-500', name: '500 Flyers', value: '500', price: 99.99 },
          { id: 'qty-1000', name: '1000 Flyers', value: '1000', price: 149.99 }
        ]
      },
      {
        name: 'Paper',
        type: 'select',
        options: [
          { id: 'paper-gloss', name: '170gsm Gloss', value: 'gloss' },
          { id: 'paper-silk', name: '170gsm Silk', value: 'silk' },
          { id: 'paper-premium', name: '250gsm Premium', value: 'premium', price: 10.00 }
        ]
      }
    ],
    inStock: true,
    rating: 4.3,
    reviews: 37,
    isFeatured: false
  },
  {
    id: '6',
    name: 'Personalized Mugs',
    category: 'Gifts',
    price: 12.99,
    description: 'Customized ceramic mugs perfect for gifts, promotions, or office use. Your design is printed with vibrant, dishwasher-safe ink.',
    features: [
      'High-quality ceramic material',
      'Dishwasher and microwave safe',
      'Full color printing',
      '11oz standard size',
      'White or colored options available'
    ],
    images: [
      'https://images.pexels.com/photos/1793035/pexels-photo-1793035.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
      'https://images.pexels.com/photos/4557482/pexels-photo-4557482.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    ],
    customizationOptions: [
      {
        name: 'Type',
        type: 'select',
        options: [
          { id: 'type-standard', name: 'Standard White Mug', value: 'standard', price: 12.99 },
          { id: 'type-colored', name: 'Colored Interior Mug', value: 'colored', price: 14.99 },
          { id: 'type-magic', name: 'Magic Reveal Mug', value: 'magic', price: 17.99 }
        ]
      },
      {
        name: 'Quantity',
        type: 'select',
        options: [
          { id: 'qty-1', name: '1 Mug', value: '1' },
          { id: 'qty-2', name: '2 Mugs', value: '2', price: 24.99 },
          { id: 'qty-4', name: '4 Mugs', value: '4', price: 45.99 },
          { id: 'qty-10', name: '10 Mugs', value: '10', price: 99.99 }
        ]
      }
    ],
    inStock: true,
    rating: 4.9,
    reviews: 153,
    isNew: true,
    isFeatured: true
  }
];

export default products;

// Helper functions for product filtering and searching
export const getProductById = (id: string): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(product => product.category.toLowerCase() === category.toLowerCase());
};

export const getFeaturedProducts = (): Product[] => {
  return products.filter(product => product.isFeatured);
};

export const getNewProducts = (): Product[] => {
  return products.filter(product => product.isNew);
};

export const searchProducts = (query: string): Product[] => {
  const searchTerm = query.toLowerCase();
  return products.filter(product => 
    product.name.toLowerCase().includes(searchTerm) ||
    product.description.toLowerCase().includes(searchTerm) ||
    product.category.toLowerCase().includes(searchTerm) ||
    (product.tags && product.tags.some(tag => tag.toLowerCase().includes(searchTerm)))
  );
};