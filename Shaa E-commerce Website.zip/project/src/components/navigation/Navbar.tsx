import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useCart } from '../../contexts/CartContext';
import { Search, ShoppingCart, User, Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const { user } = useAuth();
  const { cartItems } = useCart();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle search logic
    console.log('Searching for:', searchQuery);
  };

  const categories = [
    'Business Cards',
    'Flyers',
    'Banners',
    'Brochures',
    'T-Shirts',
    'Gifts'
  ];

  return (
    <nav className="bg-white shadow-md">
      {/* Top Navigation Bar */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className="text-2xl font-bold text-blue-700">
              PrintShop
            </span>
          </Link>

          {/* Search - Hidden on mobile */}
          <div className="hidden md:flex flex-1 mx-6">
            <form onSubmit={handleSearch} className="w-full max-w-xl relative">
              <input
                type="text"
                placeholder="Search products..."
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button
                type="submit"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-blue-700"
              >
                <Search size={20} />
              </button>
            </form>
          </div>

          {/* Nav Actions - Hidden on mobile */}
          <div className="hidden md:flex items-center space-x-4">
            <Link to="/cart" className="relative">
              <ShoppingCart className="text-gray-700 hover:text-blue-700" />
              {cartItems.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cartItems.length}
                </span>
              )}
            </Link>
            {user ? (
              <Link to="/account" className="flex items-center text-gray-700 hover:text-blue-700">
                <User size={20} className="mr-1" />
                <span>Account</span>
              </Link>
            ) : (
              <Link to="/login" className="flex items-center text-gray-700 hover:text-blue-700">
                <User size={20} className="mr-1" />
                <span>Login</span>
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700 focus:outline-none"
            onClick={toggleMenu}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Categories Navigation */}
      <div className="bg-gray-100 border-t border-gray-200">
        <div className="container mx-auto px-4">
          <ul className="hidden md:flex space-x-6 py-3">
            {categories.map((category, index) => (
              <li key={index}>
                <Link
                  to={`/products?category=${category.toLowerCase().replace(' ', '-')}`}
                  className="text-gray-700 hover:text-blue-700 font-medium"
                >
                  {category}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200 py-4">
          <div className="container mx-auto px-4">
            {/* Mobile Search */}
            <form onSubmit={handleSearch} className="mb-4">
              <input
                type="text"
                placeholder="Search products..."
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </form>

            {/* Mobile Categories */}
            <div className="mb-4">
              <h3 className="text-sm font-semibold uppercase text-gray-500 mb-2">Categories</h3>
              <ul className="space-y-2">
                {categories.map((category, index) => (
                  <li key={index}>
                    <Link
                      to={`/products?category=${category.toLowerCase().replace(' ', '-')}`}
                      className="text-gray-700 hover:text-blue-700 block py-1"
                      onClick={toggleMenu}
                    >
                      {category}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Mobile Nav Actions */}
            <div className="space-y-2 border-t border-gray-200 pt-4">
              <Link
                to="/cart"
                className="flex items-center text-gray-700 hover:text-blue-700 py-2"
                onClick={toggleMenu}
              >
                <ShoppingCart size={20} className="mr-2" />
                <span>Cart ({cartItems.length})</span>
              </Link>
              {user ? (
                <Link
                  to="/account"
                  className="flex items-center text-gray-700 hover:text-blue-700 py-2"
                  onClick={toggleMenu}
                >
                  <User size={20} className="mr-2" />
                  <span>My Account</span>
                </Link>
              ) : (
                <Link
                  to="/login"
                  className="flex items-center text-gray-700 hover:text-blue-700 py-2"
                  onClick={toggleMenu}
                >
                  <User size={20} className="mr-2" />
                  <span>Login / Register</span>
                </Link>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;