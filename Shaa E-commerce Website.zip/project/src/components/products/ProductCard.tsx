import React from 'react';
import { Link } from 'react-router-dom';
import { Star, ShoppingCart, Heart } from 'lucide-react';
import { Product } from '../../data/products';
import { useCart } from '../../contexts/CartContext';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.salePrice || product.price,
      image: product.images[0],
      quantity: 1
    });
  };

  return (
    <div className="group bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition duration-300 border border-gray-200">
      <div className="relative">
        {/* Product image */}
        <Link to={`/products/${product.id}`} className="block h-64 overflow-hidden">
          <img 
            src={product.images[0]} 
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
          />
        </Link>
        
        {/* Sale badge */}
        {product.salePrice && (
          <div className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
            SALE
          </div>
        )}
        
        {/* New badge */}
        {product.isNew && (
          <div className="absolute top-2 right-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">
            NEW
          </div>
        )}
        
        {/* Quick action buttons */}
        <div className="absolute right-2 bottom-2 flex flex-col space-y-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <button 
            className="bg-white rounded-full p-2 shadow-md hover:bg-gray-100 transition duration-300"
            aria-label="Add to wishlist"
          >
            <Heart size={20} className="text-gray-700" />
          </button>
        </div>
      </div>
      
      <div className="p-4">
        {/* Category */}
        <div className="text-xs text-gray-500 mb-1">{product.category}</div>
        
        {/* Product name */}
        <Link to={`/products/${product.id}`}>
          <h3 className="text-lg font-semibold mb-2 text-gray-800 hover:text-blue-700 transition duration-300 line-clamp-2">
            {product.name}
          </h3>
        </Link>
        
        {/* Rating stars */}
        <div className="flex items-center mb-2">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              size={16}
              className={`${
                i < Math.floor(product.rating) 
                  ? 'text-yellow-400 fill-yellow-400' 
                  : i < product.rating 
                    ? 'text-yellow-400 fill-yellow-400 opacity-50' 
                    : 'text-gray-300'
              }`}
            />
          ))}
          <span className="text-sm text-gray-500 ml-1">({product.reviews})</span>
        </div>
        
        {/* Price */}
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center">
            {product.salePrice ? (
              <>
                <span className="text-lg font-bold text-blue-700">${product.salePrice.toFixed(2)}</span>
                <span className="text-sm text-gray-500 line-through ml-2">${product.price.toFixed(2)}</span>
              </>
            ) : (
              <span className="text-lg font-bold text-blue-700">${product.price.toFixed(2)}</span>
            )}
          </div>
          
          {/* Add to cart button */}
          <button
            onClick={handleAddToCart}
            className="bg-blue-700 hover:bg-blue-800 text-white rounded-full p-2 transition duration-300"
            aria-label="Add to cart"
          >
            <ShoppingCart size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;