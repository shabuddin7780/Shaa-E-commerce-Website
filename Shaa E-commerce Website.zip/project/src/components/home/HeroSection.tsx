import React from 'react';
import { Link } from 'react-router-dom';

const HeroSection: React.FC = () => {
  return (
    <div className="relative bg-blue-700 overflow-hidden">
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="text-white order-2 md:order-1">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Custom Printing Solutions For Your Business
            </h1>
            <p className="text-lg md:text-xl mb-8 text-blue-100">
              High-quality custom printing for business cards, flyers, banners, and more. Fast delivery and exceptional service.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                to="/products"
                className="bg-orange-500 hover:bg-orange-600 text-white font-medium py-3 px-6 rounded-md transition duration-300 text-center"
              >
                Shop Now
              </Link>
              <Link
                to="/contact"
                className="bg-transparent hover:bg-blue-600 text-white border border-white font-medium py-3 px-6 rounded-md transition duration-300 text-center"
              >
                Get a Quote
              </Link>
            </div>
          </div>
          <div className="order-1 md:order-2">
            <img
              src="https://images.pexels.com/photos/5691622/pexels-photo-5691622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
              alt="Custom printing solutions"
              className="rounded-lg shadow-lg w-full"
            />
          </div>
        </div>
      </div>
      <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-orange-500 opacity-20 rounded-full"></div>
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-blue-500 opacity-20 rounded-full"></div>
    </div>
  );
};

export default HeroSection;