import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  description: string;
  image: string;
  slug: string;
}

const categories: Category[] = [
  {
    id: '1',
    name: 'Business Cards',
    description: 'Make a lasting impression',
    image: 'https://images.pexels.com/photos/6177607/pexels-photo-6177607.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    slug: 'business-cards'
  },
  {
    id: '2',
    name: 'Flyers & Brochures',
    description: 'Spread the word effectively',
    image: 'https://images.pexels.com/photos/3774043/pexels-photo-3774043.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    slug: 'flyers-brochures'
  },
  {
    id: '3',
    name: 'Banners & Signs',
    description: 'Stand out from the crowd',
    image: 'https://images.pexels.com/photos/4481262/pexels-photo-4481262.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    slug: 'banners-signs'
  },
  {
    id: '4',
    name: 'Custom Apparel',
    description: 'Wearable branding solutions',
    image: 'https://images.pexels.com/photos/1656684/pexels-photo-1656684.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    slug: 'custom-apparel'
  },
  {
    id: '5',
    name: 'Promotional Gifts',
    description: 'Memorable branded merchandise',
    image: 'https://images.pexels.com/photos/1793035/pexels-photo-1793035.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    slug: 'promotional-gifts'
  },
  {
    id: '6',
    name: 'Packaging',
    description: 'Custom boxes & packaging',
    image: 'https://images.pexels.com/photos/4040596/pexels-photo-4040596.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    slug: 'packaging'
  }
];

const FeaturedCategories: React.FC = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3">Our Products</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Browse our wide range of high-quality printing products and find the perfect solution for your business needs.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => (
            <Link 
              key={category.id} 
              to={`/products?category=${category.slug}`}
              className="group bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition duration-300"
            >
              <div className="h-48 overflow-hidden">
                <img 
                  src={category.image} 
                  alt={category.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                />
              </div>
              <div className="p-5">
                <h3 className="text-xl font-semibold mb-2 text-gray-800 group-hover:text-blue-700 transition duration-300">
                  {category.name}
                </h3>
                <p className="text-gray-600 mb-4">{category.description}</p>
                <div className="flex items-center text-blue-700 font-medium">
                  <span>Explore products</span>
                  <ChevronRight size={16} className="ml-1 group-hover:ml-2 transition-all duration-300" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCategories;