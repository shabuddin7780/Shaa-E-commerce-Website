import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, ThumbsUp, TruckIcon } from 'lucide-react';

const CallToAction: React.FC = () => {
  const benefits = [
    {
      icon: <Clock className="w-12 h-12 text-blue-700" />,
      title: 'Fast Turnaround',
      description: 'Get your orders delivered on time, every time. Most products ready to ship within 2-3 business days.'
    },
    {
      icon: <ThumbsUp className="w-12 h-12 text-blue-700" />,
      title: 'Quality Guaranteed',
      description: 'We stand behind every product we make. Not satisfied? We\'ll reprint or refund, no questions asked.'
    },
    {
      icon: <TruckIcon className="w-12 h-12 text-blue-700" />,
      title: 'Free Shipping',
      description: 'Free shipping on orders over $75. We deliver to businesses and residences nationwide.'
    }
  ];
  
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {benefits.map((benefit, index) => (
            <div key={index} className="text-center p-6 rounded-lg border border-gray-200 hover:border-blue-300 hover:shadow-md transition duration-300">
              <div className="flex justify-center mb-4">
                {benefit.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
              <p className="text-gray-600">{benefit.description}</p>
            </div>
          ))}
        </div>
        
        <div className="bg-gradient-to-r from-blue-700 to-blue-900 rounded-2xl p-8 md:p-12 text-center">
          <h2 className="text-3xl font-bold mb-4 text-white">Ready to Get Started?</h2>
          <p className="text-blue-100 mb-8 max-w-2xl mx-auto text-lg">
            Whether you're a small business or a large corporation, we have the perfect printing solutions for your needs.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link
              to="/products"
              className="bg-white hover:bg-gray-100 text-blue-700 font-medium py-3 px-6 rounded-md transition duration-300"
            >
              Shop Now
            </Link>
            <Link
              to="/contact"
              className="bg-orange-500 hover:bg-orange-600 text-white font-medium py-3 px-6 rounded-md transition duration-300"
            >
              Request a Quote
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;